<?php
session_start();
require_once 'db.php';

new source_feed();

class source_feed {
	private $db;	
	
	public function __construct() {
		$this->db = new rss_app_database();
		if(isset($_POST['new'])) {
			$this->db->add_feed($_POST['description'],$_POST['url']);
			include 'load_feeds.php';
		} else if (isset($_POST['delete'])) {
			foreach($_POST['delete_feed'] as $id) {
				$this->db->delete_feed($id);
			}
		}
		echo $this->print_page();
	}
	
	public function print_feeds() {
		$feed_list = $this->db->get_feed_list();
		$output .= '<h2>Current feeds</h2>';
		$output .= '<form name="sources" method="POST" ><table>';
		foreach($feed_list as $item) {
			$output .= '<tr><td>';
			$output .= '<input type="checkbox" name="delete_feed[]" value="'.$item['id'].'" />';
			$output .= "</td><td>";
			$output .= $item['title'];
			$output .= '</td><td>';
			$output .= '<a href="'.$item['url'].'">'.$item['url'].'</a>';
			$output .= '</td></tr>';
		}
		$output .= '</table><input type="submit" name="delete" value="Delete Feed" /></form>';
		return $output;
	}
	
	public function print_form() {
		$output .= '
			<h2>Add a new feed</h2>
			<form name="new_feed" method="POST" action="">
				Feed URL<br /><input type="text" name="url" /><br />
				Description<br /><input type="text" name="description" /><br />
				<input type="submit" name="new" value="Add Feed" />
			</form>
		';
		return $output;
	}
	
	public function print_page() {
		$output .= '
			<html>
			<head>
				<title>RSS Feeds</title>
			</head>
			<body>
				'. $this->print_form(). '<br />' . $this->print_feeds().'
			</body>
			</html>
		';
		return $output;
	}
}

?>