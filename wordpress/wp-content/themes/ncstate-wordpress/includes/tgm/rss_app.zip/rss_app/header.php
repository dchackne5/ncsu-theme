<ul>
	<li style="float:left; padding-right: 15px; list-style-type:none;"><a href="source_feed.php">Source Feeds</a></li>
	<li style="float:left; padding-right: 15px; list-style-type:none;"><a href="load_feeds.php">Refresh Feeds</a></li>
	<li style="float:left; padding-right: 15px; list-style-type:none;"><a href="select_stories.php">Stories</a></li>
	<li style="float:left; padding-right: 15px; list-style-type:none;"><a href="feed.php">Output RSS Feed</a></p></li>
</ul>
<br style="clear: both;" />