<?php

class rss_app_database {
	private $conn;
	
	public function __construct() {
		require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php';
		// Update database host, username, and password
		$this->conn = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';',DB_USER,DB_PASSWORD);
		$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_USE_BUFFERED_QUERY);
		$this->create_tables();
	}
	
	public function add_feed($title, $url) {
		$insertsql = "INSERT INTO sources (title, url) VALUES (:title, :url)";
		$query = $this->conn->prepare($insertsql);
		$query->bindParam(":title",$title);
		$query->bindParam(":url",$url);
		$query->execute();
	}
	
	public function delete_feed($id) {
		$deletesql = "DELETE FROM sources WHERE id=:id";
		$query = $this->conn->prepare($deletesql);
		$query->bindParam(":id", $id);
		$query->execute();
	}
	
	public function get_feed_list() {
		$sql = "SELECT * FROM sources";
		return $this->conn->query($sql);
	}
	
	public function get_source_stories() {
		$sql = "SELECT * FROM source_content s LEFT JOIN feed_content f ON s.id=f.source_content_id WHERE date BETWEEN date_sub(now(), INTERVAL 8 WEEK) AND now() AND f.feed_id IS NULL ORDER BY date DESC";
		$results = $this->conn->query($sql);
		if($results->rowCount()==0) {
			return false;
		} else {
			return $results;
		}
	}
	
	public function add_source_content($feed_id, $title, $description, $url, $date, $guid) {
		$insertsql = "INSERT IGNORE INTO source_content (feed_id, title, description, url, date, guid) VALUES (:feed_id, :title, :description, :url, :date, :guid)";
		$query = $this->conn->prepare($insertsql);
		$query->bindParam(":feed_id", $feed_id);
		$query->bindParam(":title",$title);
		$query->bindParam(":description",$description);
		$query->bindParam(":url",$url);
		$query->bindParam(":date",$date);
		$query->bindParam(":guid",$guid);
		$query->execute();
	}
	
	public function add_story($id) {
		$insertsql = "INSERT INTO feed_content (feed_id, source_content_id) VALUES (1, :source_content_id)";
		$query = $this->conn->prepare($insertsql);
		$query->bindParam(":source_content_id", $id);
		$query->execute();
	}
	
	public function get_feed_info($id) {
		$selectsql = "SELECT * FROM feeds WHERE id=:id";
		$query = $this->conn->prepare($selectsql);
		$query->bindParam(":id", $id);
		$query->execute();
		return $query->fetchAll();
	}
	
	public function delete_story($story_id, $feed_id) {
		$deletesql = "DELETE FROM feed_content WHERE feed_id=:feed_id AND source_content_id=:story_id";
		$query = $this->conn->prepare($deletesql);
		$query->bindParam(":feed_id", $feed_id);
		$query->bindParam(":story_id", $story_id);
		$query->execute();
	}
	
	public function get_feed_stories($id) {
		$selectsql = "SELECT * FROM source_content WHERE id IN (SELECT source_content_id FROM feed_content WHERE feed_id=:feed_id) ORDER BY date DESC";
		$query = $this->conn->prepare($selectsql);
		$query->bindParam(":feed_id",$id);
		$query->execute();
		return $query->fetchAll();
	}
	
	public function update_story($id, $title, $description, $url) {
		$updatesql = "UPDATE source_content SET title=:title, description=:description, url=:url WHERE id=:story_id";
		$query = $this->conn->prepare($updatesql);
		$query->bindParam(":title", $title);
		$query->bindParam(":description", $description);
		$query->bindParam(":story_id", $id);
		$query->bindParam(":url", $url);
		$query->execute();
	}
	
	public function get_story($id) {
		$selectsql = "SELECT * FROM source_content WHERE id=:id";
		$query = $this->conn->prepare($selectsql);
		$query->bindParam(":id", $id);
		$query->execute();
		return $query->fetchAll();
	}
	
	public function create_tables() {
			$createquery = "CREATE TABLE IF NOT EXISTS feeds (id int(11) NOT NULL AUTO_INCREMENT,title varchar(255) NOT NULL,description text NOT NULL,link varchar(255) NOT NULL,lastBuild timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,pubDate datetime NOT NULL,ttl varchar(255) NOT NULL,PRIMARY KEY (id)) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;
			

		
			CREATE TABLE IF NOT EXISTS feed_content (
			  feed_id int(11) NOT NULL,
			  source_content_id int(11) NOT NULL,
			  PRIMARY KEY (feed_id,source_content_id),
			  KEY source_content_id (source_content_id)
			) ENGINE=InnoDB DEFAULT CHARSET=latin1;
		
		
			CREATE TABLE IF NOT EXISTS sources (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  title varchar(255) NOT NULL,
			  url varchar(255) NOT NULL,
			  PRIMARY KEY (id),
			  UNIQUE KEY url (url)
			) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;
		
			CREATE TABLE IF NOT EXISTS source_content (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  feed_id int(11) NOT NULL,
			  title varchar(255) NOT NULL,
			  description text NOT NULL,
			  url varchar(255) NOT NULL,
			  date date NOT NULL,
			  guid varchar(255) NOT NULL,
			  PRIMARY KEY (id),
			  UNIQUE KEY url (url),
			  UNIQUE KEY url_2 (url),
			  KEY feed_id (feed_id)
			) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=480 ;
			";
			$this->conn->exec($createquery);
			
			$insertsql = "INSERT IGNORE INTO feeds (id, title, description, link) VALUES (1, 'RSS App Newsfeed', 'RSS App Newsfeed', :link)";
			$query = $this->conn->prepare($insertsql);
			/*$query->bindParam(":title", "RSS App Newsfeed");
			$query->bindParam(":description", "RSS App Newsfeed");*/
			$query->bindParam(":link", $_SERVER['SERVER_NAME']);
			$query->execute();
		}
}
?>