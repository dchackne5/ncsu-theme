<div class="wrap">
<h2>Your Plugin Page Title</h2>

</div>