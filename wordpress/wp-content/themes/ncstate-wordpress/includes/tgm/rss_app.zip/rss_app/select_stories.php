<?php
require_once 'db.php';

new select_stories();

class select_stories {
	private $db;
	
	public function __construct() {
		$this->db = new rss_app_database();
		if(isset($_POST['submit'])) {
			if($_POST['story_id']) {
				foreach($_POST['story_id'] as $id) {
					$this->db->add_story($id);
				}
				$this->print_page();
			} else if(isset($_POST['id'])) {
				$this->db->update_story($_POST['id'],$_POST['title'],$_POST['description'],$_POST['url']);
				$this->print_page();
			}
		} else if(isset($_POST['delete'])) {
			foreach($_POST['delete_story'] as $id) {
				$this->db->delete_story($id, 1);
			}
			$this->print_page();
		} else if(isset($_GET['id'])) {
			$this->print_edit_page();
		} else {
			$this->print_page();
		}
	}
	
	public function print_page() {
		echo '
			<html>
			<head>
				<title>Story Selection</title>
				<meta http-equiv="Content-Type"
				    content="text/html; charset=UTF-8" />
				<style type="text/css">
					table {
						margin-bottom: 20px;
						border-spacing: 1.3em;
					}
					#source_feeds {
						width: 80%;
					}
					#output_feeds {
						width: 80%;
					}
				</style>
			</head>
			<body>
			<div id="output_feeds">
				'.$this->print_output_feeds().'
			</div>
			<div id="source_feeds">
				'.$this->print_source_feeds().'
			</div>
			</body>
		';
	}
	
	public function print_source_feeds() {
		$stories = $this->db->get_source_stories();
		$output .= '<h1>Stories Not on Site</h1>';
		if($stories==false) {
			$output .= 'Only stories from the previous month are able to be selected.  Consider <a href="admin.php?page=source_feeds">adding another RSS feed</a> if more stories are needed.';
		} else {
			$output .= '<form name="source_stories" method="POST"><table>';
			foreach($stories as $story) {
				$output .= '<tr><td>';
				$output .= '<input type="checkbox" name="story_id[]" value="'.$story['id'].'" />';
				$output .= '</td><td>';
				$output .= '<a href="'.$story['url'].'">'.$story['title'].'</a>';
				$output .= '</td><td>';
				$output .= substr($story['description'],0,200);
				$output .= '</td><td>';
				$output .= '<a href="?page=rss-app&id=' . $story['id'] . '">Edit</a>';
				$output .= '</td></tr>';
			}
			$output .= '</table><input type="submit" name="submit" value="Add" /></form>';
		}
		return $output;
	}
	
	public function print_output_feeds() {
		$stories = $this->db->get_feed_stories(1);
		$output .= '<h1>Stories on Site</h1>';
		$output .= '<form name="source_stories" method="POST" ><table>';
		foreach($stories as $story) {
			$output .= '<tr><td>';
			$output .= '<input type="checkbox" name="delete_story[]" value="'.$story['id'].'" />';
			$output .= '</td><td>';
			$output .= '<a href="'.$story['url'].'">'.$story['title'].'</a>';
			$output .= '</td><td>';
			$output .= substr($story['description'],0,200);
			$output .= '</td><td>';
			$output .= '<a href="?page=rss-app&id=' . $story['id'] . '">Edit</a>';
			$output .= '</td></tr>';
			
		}
		$output .= '</table><input type="submit" name="delete" value="Remove" /></form>';
		return $output;
	}
	
	public function print_edit_page() {
		echo '
			<html>
			<head>
				<title>Story Selection</title>
				<meta http-equiv="Content-Type"
				    content="text/html; charset=UTF-8" />
				<style type="text/css">
					#story_edit input[type="text"] {
						width: 350px;
					}
				</style>
			</head>
			<body>
			<div id="story_edit">
				'.$this->print_story_edit().'
			</div>
			</body>
		';
	}
	
	public function print_story_edit() {
		$stories = $this->db->get_story($_GET['id']);
		$output .= '<h1>Story Update</h1>';
		$output .= '<form name="story_update" method="POST" action="?page=rss-app"><table>';
		foreach($stories as $story) {
			$output .= '<tr><td>Title:<br />';
			$output .= '<input type="hidden" name="id" value="'.$story['id'].'" />';
			$output .= '<input type="text" name="title" value="'.$story['title'].'" />';
			$output .= '</td></tr><tr><td>Description:<br />';
			$output .= '<textarea type="text" name="description" rows=10 cols=100>' . $story['description']. '</textarea>';
			$output .= '</td></tr><tr><td>URL:<br />';
			$output .= '<input type="text" name="url" value="'.$story['url'].'" />';
			$output .= '</td></tr>';
		}
		$output .= '</table><input type="submit" name="submit" value="Submit" /></form>';
		return $output;
	}
	
}

?>